package com.elar.watertanks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaterTanksApplication {

	public static void main(String[] args) {
		SpringApplication.run(WaterTanksApplication.class, args);
	}

}
